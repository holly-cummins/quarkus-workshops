#!/usr/bin/env bash
# tag::adocShell[]
./node_modules/.bin/ng build --configuration production --base-href "."
# end::adocShell[]

