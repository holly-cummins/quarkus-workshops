package io.quarkus.workshop.superheroes.hero;

import io.quarkus.test.junit.QuarkusIntegrationTest;

@QuarkusIntegrationTest
public class HeroResourceIT extends HeroResourceTest {
    // Execute the same tests but in packaged mode.
}
